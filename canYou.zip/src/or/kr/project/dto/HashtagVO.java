package or.kr.project.dto;

public class HashtagVO {
	private String hashtagValue;
	private int projectNo;
	public String getHashtagValue() {
		return hashtagValue;
	}
	public void setHashtagValue(String hashtagValue) {
		this.hashtagValue = hashtagValue;
	}
	public int getProjectNo() {
		return projectNo;
	}
	public void setProjectNo(int projectNo) {
		this.projectNo = projectNo;
	}
}